// Mecânica G3 — worker mínimo para instalação PWA.
// Não armazena orçamentos nem intercepta chamadas ao Firebase.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
